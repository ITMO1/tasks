#include <cmath>
#include <fstream>
#include <iostream>
#include <string>
#include <list>    
#include <iterator>
#include <locale>
#include <map>
#include <stdexcept>
#include <algorithm>
using namespace std;

void show(int *arr, int size, ofstream &out){
	for (size_t i = 0; i < size; i++)
	{
		out << arr[i] << " ";
	}
	out << endl;
}

void show(list<int> mylist, ofstream &out){
	for (std::list<int>::iterator it = mylist.begin(); it != mylist.end(); ++it)
		out << ' ' << *it;
	out << endl;
}

int mini(int *arr, int size){
	return *min_element(arr, arr + size);
}

int maxi(int *arr, int size){
	return *max_element(arr, arr + size);
}

bool chet(const int& value) { return (value % 2); }
bool nchet(const int& value) { return (value % 2) == 0; }

void main(){
	setlocale(LC_ALL, "rus");

	//����
	string Sin;
	getline(cin,Sin);

	try{
		ofstream out(Sin);
		out.exceptions(ifstream::eofbit | ifstream::failbit | ifstream::badbit);
	
		try{
			ifstream in("input.txt");
			ifstream in1("file1.txt");
			ifstream in2("file2.txt");

			in.exceptions(ifstream::eofbit | ifstream::failbit | ifstream::badbit);
			in1.exceptions(ifstream::eofbit | ifstream::failbit | ifstream::badbit);
			in2.exceptions(ifstream::eofbit | ifstream::failbit | ifstream::badbit);

		//������

			int N;
			in >> N;
			int *mas = new int[N];

			for (size_t i = 0; i < N; i++)
			{
				in >> mas[i];
			}
			out << "min: " << mini(mas, N) << " max: " << maxi(mas, N) << endl;
			show(mas, N, out);

		// c����� 
			list<int> myList(mas, mas + N);

			cout << "������� ������/ ��������? h/n ?" << endl;
			char ch;
			cin >> ch;

			if (ch == 'n') {
				myList.remove_if(chet);
			}

			else {
				myList.remove_if(nchet);
			}

			show(myList, out);

		// map
			int num, phone;
			string name;
			in1 >> num;
			map<int, string> mymap;
			map<int, string>::iterator it;

			for (size_t i = 0; i < num; i++)
			{
				in1 >> phone;
				getline(in1, name);
				mymap.insert(pair<int, string>(phone, name));
			}

			in2 >> num;
			int x1;

			for (size_t i = 0; i < num; i++)
			{
				in2 >> x1;
				try {
					if (mymap.find(x1) == mymap.end())  throw 0;
					else out << (mymap.find(x1))->second << endl;
				}
				catch (...) { continue; }
			}

			in.close();
			in1.close();
			in2.close();
		}
	catch (exception const& e){
		cout << "There was an error while openning input.txt | file1.txt | file2.txt" << e.what() << endl;
	}

	}
	catch (std::exception const& e){
		cout << "There was an error while openning output.txt " << e.what() << endl;
	}

	

}

